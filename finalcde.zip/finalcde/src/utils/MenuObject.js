import DashBoard from '../view/layout/home'
import Initiate from '../view/layout/initiate'

export const MenuObject = [
    {
        menuId:'dashboard',
        path:'/home/dashboard',
        component: DashBoard,
        isSubpage : false,
        header:true,
        menu:true
    },
    {
        menuId:'initiate',
        path:'/home/initiate',
        component: Initiate,
        isSubpage : false,
        header:true,
        menu:true
    }
]