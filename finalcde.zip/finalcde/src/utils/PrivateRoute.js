import React from 'react';
import {Redirect, Route} from 'react-router-dom';

const PrivateRoute = ({component:Component, render:Render ,...rest}) =>{
    //let {userinfo} = rest.loginDetails;
    //et loginsuccess = true;
    return(<Route
       render={
           props => (Component ? <Component {...props}/>:<Render {...props}/>)
       }
   />)
}

export default PrivateRoute;