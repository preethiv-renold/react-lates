import React from "react";
import PrivateRoute from "./PrivateRoute";
import _ from 'lodash';
import EmptyComp from "../view/common/EmptyComp";
import Header from "../view/common/header/index";
import Menu from "../view/common/menu/index";
import {MenuObject} from "./MenuObject";

const  CreatePrivateRoutes = (userinfo) => {
debugger;
    return MenuObject.map((mobj,inx)=>{
        let header = mobj.header?<Header/>:null;
        let menu = mobj.menu?<Menu />:null;
        let Custmcomp = EmptyComp;
        var restparam = {}
        if(userinfo){
            restparam = userinfo.find(function(userobj){
                return userobj.menuid===mobj.menuId
            }
            );
        }

        if(mobj.isSubpage || (restparam && restparam.menuId)){
            Custmcomp = mobj.component;
        }
        console.log("1");
        return <PrivateRoute key={inx} path={mobj.path} render={()=><div className="d-flex">{menu}<div className="article">{header}<div className="body-container"><Custmcomp {...restparam} /></div></div></div>}/>

    })
}


const  flatMenuMap = (userobj,roleval)=>{
    if(userobj) {
        let flatMenu = userobj.map( (obj) => getNestedMenuRole(obj));
        let result = _.flattenDeep(flatMenu);
    roleval.map((data,index)=>{
        result[index].role=data.role
    })
        return result;
    }
    return
}

const getNestedMenuRole = (userobj)=>{
    if(Array.isArray(userobj.subMenu)) {
        return userobj.subMenu.map((obj)=>getNestedMenuRole(obj));
    }else{
        return {menuId:userobj.menuId,role:userobj.role};
    }
}

const CustomRoute = ()=>{debugger;
    return MenuObject.map((mobj,inx)=>{
        let header = mobj.header?<Header/>:null;
        let menu = mobj.menu?<Menu />:null;
        let Custmcomp = EmptyComp;

        if(mobj.isSubpage || mobj.menuId){
            Custmcomp = mobj.component;
        }
        console.log("1");
        return <PrivateRoute key={inx} path={mobj.path} render={()=><div className="d-flex">{menu}<div className="article">{header}<div className="body-container"><Custmcomp /></div></div></div>}/>

    })
}

export default CustomRoute;