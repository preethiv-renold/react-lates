import React from 'react';

const EmptyComp = () => {
    return(
        <div></div>
    )
}

export default EmptyComp;