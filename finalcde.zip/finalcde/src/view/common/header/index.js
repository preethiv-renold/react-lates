import React from "react";

const Header = (props) => {
  return (
    <header className="App-header">
      <h2>AXIS BANK</h2>
    </header>
  );
};

export default Header;
