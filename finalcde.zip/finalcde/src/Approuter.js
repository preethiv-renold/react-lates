import React, { useReducer, useEffect } from "react";
import { MyProvider } from "./state/store/provider";
import {BrowserRouter ,Route ,Switch , Redirect} from 'react-router-dom';
import CustomRoute from "./utils/CustomRoute";
import Header from "./view/common/header/index";
import Menu from "./view/common/menu/index";
import PrivateRoute from "./utils/PrivateRoute";

const AppRouter = () => (

    <MyProvider>
            <div className="npp">
                <BrowserRouter>
                    <Switch>
                        <CustomRoute />
                    </Switch>
                </BrowserRouter>
            </div>
    </MyProvider>
)

export default AppRouter;